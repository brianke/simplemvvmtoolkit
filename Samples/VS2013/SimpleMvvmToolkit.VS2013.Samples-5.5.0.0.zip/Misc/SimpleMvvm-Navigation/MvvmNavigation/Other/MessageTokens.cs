﻿using System;

namespace MvvmNavigation
{
    public class MessageTokens
    {
        public const string Navigation = "NavigationMessageToken";
    }
}
