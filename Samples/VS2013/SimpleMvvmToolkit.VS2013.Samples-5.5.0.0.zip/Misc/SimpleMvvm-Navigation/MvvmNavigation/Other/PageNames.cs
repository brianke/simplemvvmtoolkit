﻿using System;

namespace MvvmNavigation
{
    public class PageNames
    {
        public const string Home = "Home";
        public const string About = "About";
        public const string Customer = "CustomerView";
    }
}
