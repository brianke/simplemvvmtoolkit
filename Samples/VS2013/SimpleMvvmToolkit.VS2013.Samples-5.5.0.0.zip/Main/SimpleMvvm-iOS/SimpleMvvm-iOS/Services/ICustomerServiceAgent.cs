﻿using System;
using System.Linq;

namespace SimpleMvvmiOS
{
    public interface ICustomerServiceAgent
    {
        Customer CreateCustomer();
    }
}
