Simple Mvvm Multiplatform Solution ReadMe

The Multiproject template provides a Portable Class Library with models and view models that are shared
among several different UI platforms: WPF, Silverlight, Windows Store, Windows Phone, iOS and Android.

Platform-specific projects need to use the Portable Simple Mvvm Toolkit NuGet package, which installs the
platform-specific and portable versions of the toolkit assemblies where appropriate.