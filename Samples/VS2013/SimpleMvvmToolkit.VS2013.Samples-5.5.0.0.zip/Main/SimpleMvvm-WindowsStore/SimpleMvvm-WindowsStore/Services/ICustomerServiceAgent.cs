﻿using System;
using System.Linq;

namespace SimpleMvvm_WindowsStore
{
    public interface ICustomerServiceAgent
    {
        Customer CreateCustomer();
    }
}
