Getting Started with Simple Mvvm Toolkit

The main sample app walks you through all phases of building an MVVM Silverlight
application using this toolkit.  However, I thought it would be useful to put
together a simple getting started project without the clutter of connecting to 
a SQL database and WCF service.  This sample will show you how to use the 
Visual Studio item templates, code snippets and helper classes.

For steps to follow to re-create the sample, see the online documentation
for the toolkit: http://simplemvvmtoolkit.codeplex.com/wikipage?title=Getting%20Started
