﻿using System;
using System.Linq;

namespace SimpleMvvm_Silverlight
{
    public interface ICustomerServiceAgent
    {
        Customer CreateCustomer();
    }
}
