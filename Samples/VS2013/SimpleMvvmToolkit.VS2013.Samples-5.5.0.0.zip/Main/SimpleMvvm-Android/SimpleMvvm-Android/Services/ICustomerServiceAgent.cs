﻿using System;
using System.Linq;

namespace SimpleMvvm_Android
{
    public interface ICustomerServiceAgent
    {
        Customer CreateCustomer();
    }
}
