﻿using System;
using System.Linq;

namespace SimpleMvvm_Wpf
{
    public interface ICustomerServiceAgent
    {
        Customer CreateCustomer();
    }
}
